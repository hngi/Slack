"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ACCESS_TOKEN = void 0;
var ACCESS_TOKEN = {
  TNMM726RK: ''
};
exports.ACCESS_TOKEN = ACCESS_TOKEN;