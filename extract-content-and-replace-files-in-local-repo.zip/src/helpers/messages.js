export const forbiddenMessage = {
  response_type: 'ephemeral', // private message
  text: 'You don\'t have access',
};
